// HoseinZarei 40223038
#include <stdio.h>
#include <math.h>

void solver(int *a, int *b, int *c);
void main()
{
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);
    solver(&a, &b, &c);
}
void solver(int *a, int *b, int *c)
{
    float delta = (*b) * (*b) - (4 * (*a) * (*c));
    if (delta < 0)
        printf("This equation has no real roots");
    else if (delta == 0)
    {
        float x0 = -(*b) / (2 * (*a));
        printf("it has a true root\nx0=%f", x0);
    }
    else if (delta > 0)
    {
        float x1 = ((-*b) - sqrt(delta)) / (2 * (*a));
        float x2 = ((-*b) + sqrt(delta)) / (2 * (*a));
        printf("it has two true root\nx1=%f, x2=%f", x1, x2);
    }
}